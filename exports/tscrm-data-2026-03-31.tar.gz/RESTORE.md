# T&S CRM — Database Snapshot

Exported: 2026-03-31 16:36:08
Schemas:  crm, jobs, scheduling, finance, inventory, analytics
MongoDB:  tscrm_comms

## How to restore

1. Make sure Docker is running and containers are up:
   ```
   docker compose up -d
   ```

2. Run the import script from the project root:
   ```
   ./scripts/db-import.sh /path/to/tscrm-data-2026-03-31.tar.gz
   ```

That's it. The import script will restore both PostgreSQL and MongoDB.
